# my first project
#
#
#
date > test.txt
ls
cat test.txt