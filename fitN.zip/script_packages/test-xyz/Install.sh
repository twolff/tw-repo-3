# my first project
#
#
#
date > test.txt